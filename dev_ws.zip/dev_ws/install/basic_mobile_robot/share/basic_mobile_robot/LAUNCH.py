from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[
                {'use_sim_time': False},
                str(get_package_share_directory('basic_mobile_robot')) + '/config.yaml'
            ]
        ),
        ExecuteProcess(
            cmd=['python3', str(get_package_share_directory('basic_mobile_robot')) + '/AUTONOMOUS.py'],
            output='screen'
        ),
        ExecuteProcess(
            cmd=['python3', str(get_package_share_directory('basic_mobile_robot')) + '/FINAL_MAIN.py'],
            output='screen'
        ),
        ExecuteProcess(
            cmd=['python3', str(get_package_share_directory('basic_mobile_robot')) + '/COMMANDED.py'],
            output='screen'
        ),
        ExecuteProcess(
            cmd=['python3', str(get_package_share_directory('basic_mobile_robot')) + '/ARM.py'],
            output='screen'
        )
    ])

