import cv2
import serial
import numpy as np
import pyrealsense2 as rs
from ultralytics import YOLO
import json
from tabulate import tabulate

# Initialize shared variables
default_shared_vars = {
    'sample_cmd': 0,
    'container_cmd': 0,
    'avoid_cmd': 0,
    'sample': False,
    'container': False,
    'obstacle': False
}

default_orientation = {
    'x-axis': 0,
    'y-axis': 0,
    'vertical': 0
    
}

shared_ori = default_orientation.copy()
shared_vars = default_shared_vars.copy()

def write_orientation_vars():
    with open('ori.json', 'w') as f:
        json.dump(shared_ori, f)

# Function to write shared variables to a JSON file
def write_shared_vars():
    with open('auto.json', 'w') as f:
        json.dump(shared_vars, f)

# Load your custom YOLO model
model = YOLO('/home/matrix/FINAL/finals.pt')  # Replace with the actual path to your custom model

# Set up the RealSense D455 camera
pipeline = rs.pipeline()
config = rs.config()
config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
pipeline.start(config)

# Set the depth scale
depth_scale = 0.0010000000474974513

# Create spatial and temporal filters for depth image
spatial = rs.spatial_filter()
temporal = rs.temporal_filter()

# Define colors for each class
colors = {
    'Cube': (0, 255, 0),         # green
    'Vertical': (255, 0, 0),     # blue
    'Container-s': (0, 0, 255),  # red
    # Add more colors for other classes as needed
}

def process_frame(color_image, depth_image):
    global shared_vars

    center_margin = 100

    # Detect objects using your custom YOLO model
    results = model(color_image)

    # Calculate the center of the frame
    height, width = color_image.shape[:2]
    center_x = width // 24

    # Define the coordinates for the box
    box_x, box_y = 320, 300
    box_size = 50
    top_left = (box_x - box_size // 2, box_y - box_size // 2)
    bottom_right = (box_x + box_size // 2, box_y + box_size // 2)

    # Draw a 50x50 yellow box at the specified coordinates
    cv2.rectangle(color_image, top_left, bottom_right, (0, 255, 255), 2)  # Yellow color for the box

    detection_details = []

    # Process the results
    for result in results:
        boxes = result.boxes
        for box in boxes:
            x1, y1, x2, y2 = box.xyxy[0].cpu().numpy().astype(int)
            confidence = box.conf[0].cpu().numpy()
            class_id = box.cls[0].cpu().numpy()

            if confidence < 0.5:
                continue  # Skip detections with low confidence

            # Calculate the distance to the object
            object_depth = np.median(depth_image[y1:y2, x1:x2])
            label = f"{object_depth:.2f}m"

            object_width = x2 - x1
            object_height = y2 - y1

            # Convert dimensions to real-world units
            p_to_m_w = 1.81
            p_to_m_h = 1.66
            widths = object_width * p_to_m_w
            heights = object_height * p_to_m_h

            # Get class name
            class_name = model.names[int(class_id)]

            if class_name in colors:
                color = colors[class_name]
            else:
                color = (255, 255, 255)  # Default to white if class color not defined

            def sample_follow():
                global sample_cmd

                if class_name == "Horizontal x-axis" or class_name == "Horizontal y-axis" or class_name == "Vertical":
                    shared_vars['sample'] = True
                    sample_x = int((x1 + x2) / 2)
                    sample_y = int((y1 + y2) / 2)
                    cv2.circle(color_image, (sample_x, sample_y), 5, (0, 0, 255), 3)

                    move_x = None
                    move_y = None

                    # Left and right movement
                    if sample_x < box_x - box_size:
                        shared_vars['sample_cmd'] = move_x = 'A'  # Move left
                    elif sample_x > box_x + box_size:
                        shared_vars['sample_cmd'] = move_x = 'D'  # Move right

                    # Forward and backward movement
                    if sample_y < box_y - box_size:
                        shared_vars['sample_cmd'] = move_y = 'W'  # Move forward
                    elif sample_y > box_y + box_size:
                        shared_vars['sample_cmd'] = move_y = 'S'  # Move backward

                    # If the sample is within the central box for both X and Y, stop movement
                    if box_x - box_size // 2 <= sample_x <= box_x + box_size // 2 and box_y - box_size // 2 <= sample_y <= box_y + box_size // 2:
                        shared_vars['sample_cmd'] = 'X'
                    else:
                        # Send X-axis movement if any
                        if move_x:
                            shared_vars['sample_cmd'] = move_x
                        # Send Y-axis movement if any
                        if move_y:
                            shared_vars['sample_cmd'] = move_y

                    object_detected = True

                    return True

                return False
            
            def set_orientation():
                global orientation
                if class_name == "Horizontal x-axis":
                    shared_ori['x-axis'] = 'F'
                elif class_name == "Horizontal y-axis":
                    shared_ori['y-axis'] = 'j'
                elif class_name == "Vertical":
                    shared_ori['vertical'] = 'V'

            def container_follow():
                global container_cmd

                if class_name == "Container":
                    shared_vars['container'] = True
                    container_x = int((x1 + x2) / 2)
                    container_y = int((y1 + y2) / 2)
                    cv2.circle(color_image, (container_x, container_y), 5, (0, 0, 255), 3)

                    move_x = None
                    move_y = None

                    # Left and right movement
                    if container_x < box_x - box_size:
                        shared_vars['container_cmd'] = move_x = 'A'  # Move left
                    elif container_x > box_x + box_size:
                        shared_vars['container_cmd'] = move_x = 'D'  # Move right

                    # Forward and backward movement
                    if container_y < box_y - box_size:
                        shared_vars['container_cmd'] = move_y = 'W'  # Move forward
                    elif container_y > box_y + box_size:
                        shared_vars['container_cmd'] = move_y = 'S'  # Move backward

                    # If the sample is within the central box for both X and Y, stop movement
                    if box_x - box_size // 2 <= container_x <= box_x + box_size // 2 and box_y - box_size // 2 <= container_y <= box_y + box_size // 2:
                        shared_vars['container_cmd'] = 'X'
                    else:
                        # Send X-axis movement if any
                        if move_x:
                            shared_vars['container_cmd'] = move_x
                        # Send Y-axis movement if any
                        if move_y:
                            shared_vars['container_cmd'] = move_y

                    object_detected = True

                    return True

                return False

            def avoidance():
                global avoid_cmd

                # Perform actions based on the class name
                if class_name == "rock"  or class_name == "cube":
                    shared_vars['obstacle'] = True
                    object_detected = True
                    # Check if large cube is in the left half of the frame
                    if 150 <= heights <= 400 and x2 < center_x and 1.0 <= object_depth <= 2.0:
                        large_cube = True
                        cube_condition_met_left = True
                        shared_vars['avoid_cmd'] = 'o'
                    # Check if large cube is in the right half of the frame
                    elif 150 <= heights <= 400 and x1 > center_x and 1.0 <= object_depth <= 2.0:
                        large_cube = True
                        cube_condition_met_right = True
                        shared_vars['avoid_cmd'] = 'o'
                    # Check if large cube is in the center of the frame
                    elif 150<= heights <= 400 and (
                            center_x - center_margin <= x1 <= center_x + center_margin or center_x - center_margin <= x2 <= center_x + center_margin) and 1.0 <= object_depth <= 2.0:
                        large_cube = True
                        cube_condition_met_center = True
                        shared_vars['avoid_cmd'] = 'o'
                    # Set flag to True if any object is detected
                    return True

                return False

            # Draw a rectangle around the object
            cv2.rectangle(color_image, (x1, y1), (x2, x2), (252, 119, 30), 2)

            # Add detection details to the list
            detection_details.append([class_name, f"{widths:.2f}", f"{heights:.2f}", f"{object_depth:.2f}m"])

            # Print detection details in a tabular format
            if detection_details:
                print(tabulate(detection_details, headers=["Obstacle", "Width (m)", "Height (m)", "Depth (m)"]))

            # Draw the class label and dimensions
            label = f"{class_name}: {object_depth:.2f}m"
            cv2.putText(color_image, label, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

            avoidance()
            set_orientation()
            sample_detected = sample_follow()

            if not sample_detected:
                container_follow()

    # Write updated shared variables to the JSON file
    write_shared_vars()
    write_orientation_vars()

    # Reset shared_vars and orientation to default values
    shared_vars = default_shared_vars.copy()
    orientation = default_orientation.copy()

    return color_image

frame_skip = 5
frame_count = 0

try:
    while True:
        # Get the latest frame from the camera
        frames = pipeline.wait_for_frames()
        color_frame = frames.get_color_frame()
        depth_frame = frames.get_depth_frame()

        if frame_count % frame_skip == 0:
            # Convert the frames to numpy arrays
            color_image = np.asanyarray(color_frame.get_data())
            depth_image = np.asanyarray(depth_frame.get_data())

            # Apply filters to depth image
            depth_frame = spatial.process(depth_frame)
            depth_frame = temporal.process(depth_frame)
            depth_image = np.asanyarray(depth_frame.get_data())

            # Convert the depth image to meters
            depth_image = depth_image * depth_scale

            # Process the frame in a separate thread to avoid blocking the main loop
            processed_image = process_frame(color_image, depth_image)

            # Show the processed image
            cv2.imshow("Color Image", processed_image)

        frame_count += 1

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    # Revert shared variables and orientation to default values
    with open('auto.json', 'w') as f:
        json.dump(default_shared_vars, f)
        
    with open('ori.json', 'w') as f:
        json.dump(default_orientation, f)

    # Stop the pipeline
    pipeline.stop()
