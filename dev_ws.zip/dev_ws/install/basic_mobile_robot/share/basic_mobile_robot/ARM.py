import cv2
import numpy as np
import serial
import json


nano = serial.Serial(port='/dev/ttyUSB1', baudrate=115200, timeout=1)

def initialize_data_cv():
    return {
        'cv_sample_cmd': 0,
        'cv_sample_cmd_x': 0,
        'cv_sample_cmd_y': 0,
        'cv_container_cmd': 0,
        'cv_container_cmd_x': 0,
        'cv_container_cmd_y': 0,
        'cv_sample': False,
        'cv_container': False,
        'contour': 0
        
    }


def read_shared_ori():
    with open('ori.json', 'r') as f:
        return json.load(f)
    
data_cv = initialize_data_cv()

def write_shared_vars():
    with open('cv.json', 'w') as f:
        json.dump(data_cv, f)

def read_nano():
    if nano.in_waiting > 0:
        line = nano.readline().decode('utf-8').strip()
        print(f"Received from Nano: {line}")
        return line
    return None



def send_nano(var):
    message = f"{var}\n"
    nano.write(message.encode('utf-8'))
    print(f"Sent: {message.strip()}")



def nothing(x):
    pass

def adjust_position_red(sample_x, sample_y, center_x, center_y, box_size):
    global sample_arm_moving 
    data_cv['cv_sample'] = True
    if sample_arm_moving:
        return 'X', 'X'  # Don't send any movement commands if the arm is moving
    
    x_command_r = ''
    y_command_r = ''
    
    if sample_x < center_x - box_size:
        data_cv['cv_sample_cmd_x'] = x_command_r = 'A'  # Move left
    elif sample_x > center_x + box_size:
        data_cv['cv_sample_cmd_x'] = x_command_r = 'D'  # Move right
    else:
        data_cv['cv_sample_cmd_x'] = x_command_r = 'X'  # Stop X movement
    
    if sample_y < center_y - box_size:
        data_cv['cv_sample_cmd_y'] = y_command_r = 'W'  # Move forward
    elif sample_y > center_y + box_size:
        data_cv['cv_sample_cmd_y'] = y_command_r = 'S'  # Move backward
    else:
        data_cv['cv_sample_cmd_y'] = y_command_r = 'X'  # Stop Y movement

    if x_command_r == 'X' and y_command_r == 'X':
        data_cv['cv_sample_cmd'] = 'X'
        if not sample_arm_moving:  # Only send the arm command if it is not already moving
            sample_arm_moving = True
            if x_axis:
                send_nano(x_axis)
            elif y_axis:
                send_nano(y_axis)
            elif vertical:
                send_nano(vertical)

            
            
    else:
        if not sample_arm_moving:  # Only move the rover if the arm is not moving
            data_cv['cv_sample_cmd_x'] = x_command_r
            data_cv['cv_sample_cmd_y'] = y_command_r
 
    return x_command_r, y_command_r

def adjust_position_blue(container_x, container_y, center_x, center_y, box_size):
    global container_arm_moving
    data_cv['cv_container'] = True
    if container_arm_moving:
        return 'X', 'X'  # Don't send any movement commands if the arm is moving
    
    x_command_b = ''
    y_command_b = ''

    received_signal_1 = read_nano()
    if received_signal_1 == 'Z' and sample_detected:
        sample()
    
    if container_x < center_x - box_size:
        data_cv['cv_container_cmd_x'] = x_command_b = 'A'  # Move left
    elif container_x > center_x + box_size:
        data_cv['cv_container_cmd_x'] = x_command_b = 'D'  # Move right
    else:
        data_cv['cv_container_cmd_x'] = x_command_b = 'X'  # Stop X movement
    
    if container_y < center_y - box_size:
        data_cv['cv_container_cmd_y'] = y_command_b = 'W'  # Move forward
    elif container_y > center_y + box_size:
        data_cv['cv_container_cmd_y'] = y_command_b = 'S'  # Move backward
    else:
        data_cv['cv_container_cmd_y'] = y_command_b = 'X'  # Stop Y movement

    if x_command_b == 'X' and y_command_b == 'X':
        data_cv['cv_container_cmd'] = 'X'
        if not container_arm_moving:  # Only send the arm command if it is not already moving
            send_nano('C')
            container_arm_moving = True

    else:
        if not container_arm_moving:  # Only move the rover if the arm is not moving
            data_cv['cv_container_cmd_x'] = x_command_b
            data_cv['cv_container_cmd_y'] = y_command_b
    
    return x_command_b, y_command_b

contour_drawn = False

def sample():
    global contour_drawn
    
    r_l_h = cv2.getTrackbarPos("RLH", "Tracking")
    r_l_s = cv2.getTrackbarPos("RLS", "Tracking")
    r_l_v = cv2.getTrackbarPos("RLV", "Tracking")
    r_u_h = cv2.getTrackbarPos("RUH", "Tracking")
    r_u_s = cv2.getTrackbarPos("RUS", "Tracking")
    r_u_v = cv2.getTrackbarPos("RUV", "Tracking")

    lower_red = np.array([r_l_h, r_l_s, r_l_v])
    upper_red = np.array([r_u_h, r_u_s, r_u_v])

    mask_r = cv2.inRange(hsv_frame, lower_red, upper_red)

    contours_r, _ = cv2.findContours(mask_r, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    max_contour_r = None

    if len(contours_r) > 0:
        max_contour_r = max(contours_r, key=cv2.contourArea)

    if max_contour_r is not None:
        contour_area_r = cv2.contourArea(max_contour_r)
        if contour_area_r > 400:
            cv2.drawContours(frame, [max_contour_r], -1, (0, 255, 0), 2)
            M = cv2.moments(max_contour_r)
            if M["m00"] != 0:
                sample_x = int(M["m10"] / M["m00"])
                sample_y = int(M["m01"] / M["m00"])
                print("Sample Coordinate: ({}, {})".format(sample_x, sample_y))
                cv2.circle(frame, (sample_x, sample_y), 5, (0, 0, 255), 3)
                cv2.putText(frame, 'Sample', (sample_x, sample_y), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
                
                x_command_r, y_command_r = adjust_position_red(sample_x, sample_y, center_x, center_y, box_size)
                print("X Command r: {}, Y Command r: {}".format(x_command_r, y_command_r))
                contour_drawn = True
                return True
    return False

def container():
    global contour_drawn

    b_l_h = cv2.getTrackbarPos("BLH", "Tracking")
    b_l_s = cv2.getTrackbarPos("BLS", "Tracking")
    b_l_v = cv2.getTrackbarPos("BLV", "Tracking")
    b_u_h = cv2.getTrackbarPos("BUH", "Tracking")
    b_u_s = cv2.getTrackbarPos("BUS", "Tracking")
    b_u_v = cv2.getTrackbarPos("BUV", "Tracking")

    lower_blue = np.array([b_l_h, b_l_s, b_l_v])
    upper_blue = np.array([b_u_h, b_u_s, b_u_v])

    mask_b = cv2.inRange(hsv_frame, lower_blue, upper_blue)

    contours_b, _ = cv2.findContours(mask_b, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    max_contour_b = None

    if len(contours_b) > 0:
        max_contour_b = max(contours_b, key=cv2.contourArea)

    if max_contour_b is not None:
        contour_area_b = cv2.contourArea(max_contour_b)
        if contour_area_b > 400:
            cv2.drawContours(frame, [max_contour_b], -1, (0, 255, 0), 2)
            M = cv2.moments(max_contour_b)
            if M["m00"] != 0:
                container_x = int(M["m10"] / M["m00"])
                container_y = int(M["m01"] / M["m00"])
                print("Container Coordinate: ({}, {})".format(container_x, container_y))
                cv2.circle(frame, (container_x, container_y), 5, (255, 0, 0), 3)
                cv2.putText(frame, 'Container', (container_x, container_y), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)
                
                x_command_b, y_command_b = adjust_position_blue(container_x, container_y, center_x, center_y, box_size)
                print("X Command b: {}, Y Command b: {}".format(x_command_b, y_command_b))
                contour_drawn = True

# Initialize webcam
cap = cv2.VideoCapture(6)

cv2.namedWindow("Tracking")
cv2.resizeWindow("Tracking", 640, 240)
cv2.createTrackbar("RLH", "Tracking", 0, 255, nothing)
cv2.createTrackbar("RLS", "Tracking", 0, 255, nothing)
cv2.createTrackbar("RLV", "Tracking", 0, 255, nothing)
cv2.createTrackbar("RUH", "Tracking", 255, 255, nothing)
cv2.createTrackbar("RUS", "Tracking", 255, 255, nothing)
cv2.createTrackbar("RUV", "Tracking", 255, 255, nothing)

cv2.createTrackbar("BLH", "Tracking", 0, 255, nothing)
cv2.createTrackbar("BLS", "Tracking", 0, 255, nothing)
cv2.createTrackbar("BLV", "Tracking", 0, 255, nothing)
cv2.createTrackbar("BUH", "Tracking", 255, 255, nothing)
cv2.createTrackbar("BUS", "Tracking", 255, 255, nothing)
cv2.createTrackbar("BUV", "Tracking", 255, 255, nothing)

# Set initial values for the HSV trackbars
cv2.setTrackbarPos("RLH", "Tracking", 0)
cv2.setTrackbarPos("RLS", "Tracking", 89)
cv2.setTrackbarPos("RLV", "Tracking", 44)
cv2.setTrackbarPos("RUH", "Tracking", 15)
cv2.setTrackbarPos("RUS", "Tracking", 255)
cv2.setTrackbarPos("RUV", "Tracking", 255)

cv2.setTrackbarPos("BLH", "Tracking", 100)
cv2.setTrackbarPos("BLS", "Tracking", 50)
cv2.setTrackbarPos("BLV", "Tracking", 50)
cv2.setTrackbarPos("BUH", "Tracking", 140)
cv2.setTrackbarPos("BUS", "Tracking", 255)
cv2.setTrackbarPos("BUV", "Tracking", 255)

# Initialize arm moving flag
sample_arm_moving = False
container_arm_moving = False

while cap.isOpened():

    data_cv = initialize_data_cv()

    shared_ori = read_shared_ori()

    ret, frame = cap.read()
    frame = cv2.resize(frame, (640, 480))

    if not ret:
        print("Error reading frame from webcam")
        break

    height, width, _ = frame.shape

    # Calculate the center of the frame
    center_x = width // 2
    center_y = (height // 2) + 70

    # Define the size of the alignment box
    box_size = 10

    # Draw a rectangle at the center of the frame
    cv2.rectangle(frame, (center_x - box_size, center_y - box_size), (center_x + box_size, center_y + box_size), (0, 0, 0), 2)
    print("Center Coordinate: ({}, {})".format(center_x, center_y))

    hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    
    x_axis = shared_ori['x-axis']
    y_axis = shared_ori['y-axis']
    vertical = shared_ori['vertical']
    
    # Process sample first
    sample_detected = sample()

    # If no sample is detected, process the container
    if not sample_detected:
        container()

     #   sample_detected = sample() 
    if not contour_drawn:
        data_cv['contour'] = 'X'
        print("No contours found, sending stop command 'X'")

    write_shared_vars()

    cv2.imshow('Webcam', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    # Check if the arm has finished moving
    if sample_arm_moving:
        received_signal = read_nano()
        if received_signal == 'Y':  # Assuming 'Y' is the signal from Nano indicating the arm has finished moving
            sample_arm_moving = False
    if container_arm_moving:
        received_signal = read_nano()
        if received_signal == 'Z':  # Assuming 'Y' is the signal from Nano indicating the arm has finished moving
            container_arm_moving = False
cap.release()
cv2.destroyAllWindows()
