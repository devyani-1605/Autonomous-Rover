import json
import serial
import time
import os

esp = serial.Serial(port='/dev/ttyUSB1', baudrate=9600, timeout=1)

# File paths
json_file = 'data.json'
command_json_file = 'command.json'
autonomous_json_file = 'auto.json'
opencv_json_file = 'cv.json'
arm_json_file = 'arm_moving.json'


def send_esp(data):
    message = f"{data}\n"
    esp.write(message.encode('utf-8'))
    print(f"Sent: {message.strip()}")


def read_from_microcontroller(serial_port):
    with serial.Serial(serial_port, 9600, timeout=1) as ser:
        while True:
            if ser.in_waiting > 0:
                line = ser.readline().decode('utf-8').rstrip()
                return line


def read_json_file(json_file):
    try:
        with open(json_file, 'r') as f:
            data_dict = json.load(f)
        return data_dict['data']
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def read_auto_json_file(json_file):
    try:
        with open(json_file, 'r') as f:
            shared_vars = json.load(f)
        return shared_vars
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def initialize_json_file(opencv_file,arm_file):
    if not os.path.exists(opencv_file) or os.stat(opencv_file).st_size == 0:
        data_cv = {
            'cv_sample_cmd': 'X',
            'cv_sample_cmd_x': 'X',
            'cv_sample_cmd_y': 'X',
            'cv_container_cmd': 'X',
            'cv_container_cmd_x': 'X',
            'cv_container_cmd_y': 'X',
            'cv_sample': False,
            'cv_container': False
        }
        with open(opencv_file, 'w') as f:
            json.dump(data_cv, f)
            
    # Initialize arm JSON file if it doesn't exist or is empty
    if not os.path.exists(arm_file) or os.stat(arm_file).st_size == 0:
        data_arm = {
            'sample_arm_moving': 0,
            'container_arm_moving': 0,
            'sample_arm': 0,
            'container_arm': 0
        }
        with open(arm_file, 'w') as f:
            json.dump(data_arm, f)


def read_cv_json_file(json_file):
    try:
        with open(json_file, 'r') as f:
            data = json.load(f)
        return data
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Error reading JSON file: {e}")
        return None


def main():
    serial_port = '/dev/ttyUSB1'  # Replace with your microcontroller's serial port

    initialize_json_file(opencv_json_file,arm_json_file)

    while True:
        data = read_from_microcontroller(serial_port)
        data_dict = {'data': data}
        
        with open(json_file, 'w') as f:
            json.dump(data_dict, f)

        data = read_json_file(command_json_file)
        shared_vars = read_auto_json_file(autonomous_json_file)
        shared_cv = read_cv_json_file(opencv_json_file)
        arm_moving = read_cv_json_file(arm_json_file)
        
        if shared_vars is None or shared_cv is None:
            print("No data received from JSON file.")
            continue
        
        # Access the autonomous variables
        sample_cmd = shared_vars['sample_cmd']
        container_cmd = shared_vars['container_cmd']
        avoid_cmd = shared_vars['avoid_cmd']
        sample = shared_vars['sample']
        container = shared_vars['container']
        obstacle = shared_vars['obstacle']

        # Access the OpenCV variables
        sample_cmd_x = shared_cv['cv_sample_cmd_x']
        sample_cmd_y = shared_cv['cv_sample_cmd_y']
        sample_cmd_cv = shared_cv['cv_sample_cmd']
        container_cmd_x = shared_cv['cv_container_cmd_x']
        container_cmd_y = shared_cv['cv_container_cmd_y']
        container_cmd_cv = shared_cv['cv_container_cmd']
        sample_cv = shared_cv['cv_sample']
        container_cv = shared_cv['cv_container']
        
        sample_arm_moving = arm_moving['sample_arm_moving']
        container_arm_moving = arm_moving['container_arm_moving']
        sample_arm = arm_moving['sample_arm']
        container_arm = arm_moving['container_arm']

        # Print the variables (or perform other actions)
        print(f"Sample Command: {sample_cmd}, Container Command: {container_cmd}, Avoid Command: {avoid_cmd}")
        print(f"Sample: {sample}, Container: {container}, Obstacle: {obstacle}")
        print(f"Sample Command x: {sample_cmd_x}, Sample Command y: {sample_cmd_y}, Container Command x: {container_cmd_x}, Container Command y: {container_cmd_y}, Sample Command CV: {sample_cmd_cv}, Container Command CV: {container_cmd_cv}")
        print(f"Sample CV: {sample_cv}, Container CV: {container_cv}")

        if sample and not obstacle:
            print("auto")
            send_esp(sample_cmd)
        elif container and not sample and not obstacle: 
            print("auto")
            send_esp(container_cmd)
        elif obstacle and sample and container:
            send_esp(avoid_cmd)
        elif obstacle:
            send_esp(avoid_cmd)
        elif sample_cmd == 'X':
            print("opencv")
            if sample_cv:
                if sample_cv or sample_arm == 'Y':
                    send_esp(sample_cmd_x)
                    time.sleep(0.05)
                    send_esp(sample_cmd_y)
                    if sample_cmd_x == 'X' and sample_cmd_y == 'X' and sample_arm_moving == 'U':
                        send_esp(sample_cmd)
        elif container_cmd == 'X':
            if container_cv:
                if container_cv or container_arm == 'Z':
                    send_esp(container_cmd_x)
                    time.sleep(0.05)
                    send_esp(container_cmd_y)
                    if container_cmd_x == 'X' and container_cmd_y == 'X' and container_arm_moving == 'R':
                        send_esp(container_cmd)
        else:
            print("commanded")
            send_esp(data)

        # Sleep for a short duration before reading again
        time.sleep(0.1)


if __name__ == "__main__":
    main()

