import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, Point
from tf_transformations import euler_from_quaternion
import math
import json

command_json_file = 'command.json'
data_dict = {}

def read_json_file(json_file):
    try:
        with open(json_file, 'r') as f:
            data_dict = json.load(f)
        return data_dict['data']
    except (FileNotFoundError, json.JSONDecodeError):
        return None

class ESP32PublisherNode(Node):

    def __init__(self):
        super().__init__('esp32_publisher_node')

        self.imu_publisher = self.create_publisher(Imu, '/imu/data', 20)
        self.odometry_publisher = self.create_publisher(Odometry, '/wheel_odometry', 20)
        self.create_subscription(Odometry, '/odometry/filtered', self.odometry_callback, 20)
        
        self.timer = self.create_timer(0.5, self.publish_sensor_data)

        self.goal_points = []
        self.current_goal_index = 0

    def publish_sensor_data(self):
     
            try:
                json_file = 'data.json'
                line = read_json_file(json_file)
                self.get_logger().info(f'Received line from serial: {line}')
                
                data = line.split(',')
                if len(data) != 14:
                    self.get_logger().error(f'Unexpected data format: {data}')
                  
                
                ay, ax, az = float(data[0]), float(data[1]), float(data[2])
                qx, qy, qz, qw = float(data[3]), float(data[4]), float(data[5]), float(data[6])
                vx = float(data[13])
                timestamp = self.get_clock().now().to_msg()
                
                # Publish IMU data
                imu_msg = Imu()
                imu_msg.header.stamp = timestamp
                imu_msg.header.frame_id = 'base_link'
                imu_msg.linear_acceleration.x = ax
                imu_msg.linear_acceleration.y = ay
                imu_msg.linear_acceleration.z = az
                imu_msg.orientation = Quaternion(x=qx, y=qy, z=qz, w=qw)
                self.imu_publisher.publish(imu_msg)
                self.get_logger().info('Published IMU data')

                # Publish wheel odometry data
                odom_msg = Odometry()
                odom_msg.header.stamp = timestamp
                odom_msg.header.frame_id = 'odom'
                odom_msg.child_frame_id = 'base_link'
                odom_msg.twist.twist.linear.x = vx
                odom_msg.twist.twist.linear.y = 0.00
                odom_msg.pose.pose.orientation = Quaternion(x=qx, y=qy, z=qz, w=qw)
                odom_msg.pose.pose.position = Point(x=0.0, y=0.0, z=0.0)  # Dummy position data
                self.odometry_publisher.publish(odom_msg)
                self.get_logger().info('Published odometry data')
            
            except Exception as e:
                self.get_logger().error(f'Error reading from serial port: {e}')

    def odometry_callback(self, msg):
        print("hello")
        current_x = msg.pose.pose.position.x
        current_y = msg.pose.pose.position.y

        # Extract the orientation in quaternion
        orientation_q = msg.pose.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]

        # Convert quaternion to euler angles
        (roll, pitch, yaw) = euler_from_quaternion(orientation_list)
        current_yaw = self.normalize_angle(math.degrees(yaw)) 
        

        if self.goal_points:
            goal_x, goal_y = self.goal_points[self.current_goal_index]
            distance, angle_to_goal = self.calculate_distance_and_angle(current_x, current_y, goal_x, goal_y)
            self.get_logger().info(f'angle_to_goal: {angle_to_goal}')
            self.get_logger().info(f'current_yaw: {current_yaw}')
            self.get_logger().info(f'distance: {distance}')
            self.get_logger().info(f'current_coordinate : {current_x, current_y}')
            self.get_logger().info(f'current_goal : {goal_x, goal_y}')
            
            if angle_to_goal - current_yaw >= 2 :
                data = 'A'
                data_dict = {'data': data}
                with open(command_json_file, 'w') as f:
                    json.dump(data_dict, f)
                   
            elif angle_to_goal - current_yaw <= -2:
                data = 'D'
                data_dict = {'data': data}
                with open(command_json_file, 'w') as f:
                    json.dump(data_dict, f)
                
            elif distance > 0.5:
                data = 'W'
                data_dict = {'data': data}
                with open(command_json_file, 'w') as f:
                    json.dump(data_dict, f)
            else:
                data = 'X'
                data_dict = {'data': data}
                with open(command_json_file, 'w') as f:
                    json.dump(data_dict, f)
                self.update_goal()

    def calculate_distance_and_angle(self, current_x, current_y, goal_x, goal_y):
        distance = math.sqrt((goal_x - current_x)**2 + (goal_y - current_y)**2)
        angle = math.atan2(goal_y - current_y, goal_x - current_x)
        angle_to_goal = self.normalize_angle(math.degrees(angle))
        return distance, angle_to_goal
        
    def normalize_angle(self, angle):
        if angle < 0:
            normalize_angle = angle + 360
            return normalize_angle
        else:
            normalize_angle = angle
            return angle


    def set_goal_points(self, goal_points):
        self.goal_points = goal_points
        self.current_goal_index = 0

    def update_goal(self):
        if self.current_goal_index < len(self.goal_points) - 1:
            self.current_goal_index += 1
        else:
            self.get_logger().info('All goals reached.')
            self.goal_points = []
            self.current_goal_index = 0

    def __del__(self):
        if self.serial_connection.is_open:
            self.serial_connection.close()

def main(args=None):
    rclpy.init(args=args)
    esp32_publisher_node = ESP32PublisherNode()


    # Example of setting multiple goal points. You might want to get these values from somewhere else
    goals = [(9.9,1.35),(11.5,8.3),(11.3,4.35),(11.4,4.35)]
    
    esp32_publisher_node.set_goal_points(goals)

    rclpy.spin(esp32_publisher_node)
    esp32_publisher_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
