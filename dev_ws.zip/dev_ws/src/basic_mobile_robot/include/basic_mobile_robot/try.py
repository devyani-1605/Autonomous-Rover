import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, Point
from tf_transformations import euler_from_quaternion
import serial
import math

class ESP32PublisherNode(Node):

    def __init__(self):
        super().__init__('esp32_publisher_node')

        self.declare_parameter('serial_port', '/dev/ttyUSB0')
        self.declare_parameter('baud_rate', 115200)
        
        serial_port = self.get_parameter('serial_port').value
        baud_rate = self.get_parameter('baud_rate').value
        
        try:
            self.serial_connection = serial.Serial(serial_port, baud_rate, timeout=1)
        except serial.SerialException as e:
            self.get_logger().error(f'Failed to connect to serial port {serial_port} at baud rate {baud_rate}: {e}')
            return
        
        self.imu_publisher = self.create_publisher(Imu, '/imu/data', 10)
        self.odometry_publisher = self.create_publisher(Odometry, '/wheel_odometry', 10)
        
        self.odom_sub = self.create_subscription(Odometry, '/odometry/filtered', self.odometry_callback, 103)
        
        self.timer = self.create_timer(0.1, self.publish_sensor_data)
        
        self.goal_x = None
        self.goal_y = None
        self.current_x = 0
        self.current_y = 0

    def publish_sensor_data(self):
        while self.serial_connection.in_waiting > 0:
            try:
                line = self.serial_connection.readline().decode('utf-8').strip()
                self.get_logger().info(f'Received line from serial: {line}')
                
                data = line.split(',')
                if len(data) != 8:
                    self.get_logger().error(f'Unexpected data format: {data}')
                    continue
                
                ax, ay, az = float(data[0]), float(data[1]), float(data[2])
                qx, qy, qz, qw = float(data[3]), float(data[4]), float(data[5]), float(data[6])
                vx = float(data[7])
                timestamp = self.get_clock().now().to_msg()
                
                # Publish IMU data
                imu_msg = Imu()
                imu_msg.header.stamp = timestamp
                imu_msg.header.frame_id = 'base_link'
                imu_msg.linear_acceleration.x = ax
                imu_msg.linear_acceleration.y = ay
                imu_msg.linear_acceleration.z = az
                imu_msg.orientation = Quaternion(x=qx, y=qy, z=qz, w=qw)
                self.imu_publisher.publish(imu_msg)
                self.get_logger().info('Published IMU data')

                # Publish wheel odometry data
                odom_msg = Odometry()
                odom_msg.header.stamp = timestamp
                odom_msg.header.frame_id = 'odom'
                odom_msg.child_frame_id = 'base_link'
                odom_msg.twist.twist.linear.x = vx
                odom_msg.twist.twist.linear.y = 0.00
                odom_msg.pose.pose.orientation = Quaternion(x=qx, y=qy, z=qz, w=qw)
                odom_msg.pose.pose.position = Point(x=0.0, y=0.0, z=0.0)  # Dummy position data
                self.odometry_publisher.publish(odom_msg)
                self.get_logger().info('Published odometry data')
            
            except Exception as e:
                self.get_logger().error(f'Error reading from serial port: {e}')

    def odometry_callback(self, msg):
        current_x = msg.pose.pose.position.x
        current_y = msg.pose.pose.position.y

        # Extract the orientation in quaternion
        orientation_q = msg.pose.pose.orientation
        orientation_list = [msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w]

        # Convert quaternion to euler angles
        (roll, pitch, yaw) = euler_from_quaternion(orientation_list)
        current_yaw = math.degrees(yaw)

        if self.goal_x is not None and self.goal_y is not None:
            distance, angle_to_goal = self.calculate_distance_and_angle(current_x, current_y, self.goal_x, self.goal_y)
            angle_difference = self.normalize_angle(angle_to_goal - current_yaw)
            
            
            if abs(angle_difference) > 0.1:
                if angle_difference > 0:
                    self.send_command('D')  # Right

                else:
                    self.send_command('A')  # Left
            elif distance > 0.1:
                self.send_command('W')  # Forward
            else:
                self.send_command('X')  # Stop

    def calculate_distance_and_angle(self, current_x, current_y, goal_x, goal_y):
        distance = math.sqrt((goal_x - current_x)**2 + (goal_y - current_y)**2)
        angle = math.atan2(goal_y - current_y, goal_x - current_x)
        angle_to_goal = math.degrees(angle)
      
        return distance, angle_to_goal
        

    def normalize_angle(self, angle):
        while angle > 180:
            angle -= 360
        while angle < -180:
            angle += 360
        return angle

    def send_command(self, command):
        self.serial_connection.write(command.encode())

    def set_goal(self, goal_x, goal_y):
        self.goal_x = goal_x
        self.goal_y = goal_y

    def __del__(self):
        if self.serial_connection.is_open:
            self.serial_connection.close()

def main(args=None):
    rclpy.init(args=args)
    esp32_publisher_node = ESP32PublisherNode()

    # Example of setting a goal. You might want to get these values from somewhere else
    esp32_publisher_node.set_goal(2.0, 0.0)

    rclpy.spin(esp32_publisher_node)
    esp32_publisher_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
