from setuptools import setup

package_name = 'basic_mobile_robot'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/ekf_launch.py']),
        ('share/' + package_name + '/config', ['config/ekf.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='your_name',
    maintainer_email='your_email@example.com',
    description='Basic mobile robot package with IMU and encoder data publisher, integrated with robot localization.',
    license='Your license',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'esp32_publisher_node = basic_mobile_robot.esp32_publisher_node:main',
        ],
    },
)
